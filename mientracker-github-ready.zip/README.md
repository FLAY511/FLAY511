# MIENTracker (Private Educational Use Only)

MIENTracker adalah simulasi pelacakan nomor telepon untuk edukasi dan penanganan kasus kehilangan HP **dengan izin**. Tidak diperbolehkan menggunakan proyek ini untuk pelacakan orang tanpa persetujuan.

## Cara Pakai

1. Buka `PELACAK.html` di browser
2. Masukkan nomor telepon (milik sendiri atau atas izin)
3. Izinkan akses lokasi jika diminta
4. Lokasi akan dikirim ke Telegram (jika konfigurasi aktif)

## ⚠️ PERINGATAN
Proyek ini hanya boleh digunakan untuk:
- Uji coba pribadi
- Penanganan kehilangan HP dengan izin pemilik

JANGAN digunakan untuk keperluan ilegal.

---
**Developer:** M. Rafka Brian S. | 🇮🇩 Tuban, 2025