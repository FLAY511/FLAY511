
# MIENTracker - PIN SHA256 Protected Version

Versi ini dilengkapi dengan sistem proteksi PIN SHA-256. Tidak ada PIN asli disimpan dalam file, hanya hash-nya.

## Fitur
- PIN aman (tidak bisa dilihat dari source code)
- Tidak perlu backend / server
- Cocok untuk simulasi pelacakan pribadi

## Penggunaan
1. Buka halaman `index.html` di browser
2. Masukkan PIN: `flay121211`
3. Jika benar, konten utama terbuka
4. Dapat digunakan di GitHub Pages (aktifkan via Settings > Pages)

⚠️ Jangan gunakan untuk melacak orang lain tanpa izin.
